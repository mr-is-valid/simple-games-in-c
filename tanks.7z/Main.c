#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>

const int  Row=11;//the number of the row in the game
const int  Col=11;// the number of the col in the game
const int  RowExseption=13;//the number of the row exception in the game
const int  ColExseption=13;//the number of the col exception in the game
int  Option; //the option of the game
int  Turn_Tank1=1,Turn_Tank2=0;//the turn in the game


//print the array
void Print(char Game[RowExseption][ColExseption])
{	
	int i=0;
	int j=0;
	for(i=0;i<13;i++)
	{
		for(j=0;j<13;j++)
		{
			printf("%5c",Game[i][j]);
		}
		printf("\n");
	}
}//end print



void Fill_The_Array(char Game[RowExseption][ColExseption])
{
	int i=0;
	int j=0;
	//fill the save wall
	for(i=0;i<RowExseption;i++)
	{
		Game[i][0]='@';
		Game[i][ColExseption-1]='@';
	}

	//fill the save wall
	for(j=0;j<ColExseption;j++)
	{
		Game[0][j]='@';
		Game[RowExseption-1][j]='@';
	}

	//fill the break walls
	for(i=1;i<Row+1;i++)
	{
		for(j=1;j<Col+1;j++)
		{
			if( (i)%2==0 && (j)%2==0 )Game[i][j]='X';
			else Game[i][j]='-';
		}
	}

	//place the tanks
	Game[RowExseption/2][1]='O';
	Game[ColExseption/2][Col]='O';

}//end Fill_The_Array



void Shot_Bomb(char Game[RowExseption][ColExseption],int x,int y)
{
	for(int i=x-1; i<x+2 ;i++)
	{
		for(int j=y-1 ;j<y+2;j++)
		{
			if(Game[i][j]=='O' && Turn_Tank1==1 && Game[i][j]!='@')
				{
					Game[i][j]= '0' + (rand() % 2);
					Option=999;
					printf("Tank1 win \n");
				}
			else 
				if(Game[i][j]=='O' && Turn_Tank2==1 && Game[i][j]!='@')
					{
						Game[i][j]= '0' + (rand() % 2);
						Option=999;
						printf("Tank2 win \n");
					}
			else if(Game[i][j]!='@')Game[i][j]= '0' + (rand() % 2);
		}
	}
}//end bomb shot

void Shot_Normal_Shot (char Game[RowExseption][ColExseption] ,int row ,int col)
{
	int Check_Hit=1;
	int Direction_Shot;
	printf("1. to move up \n");
	printf("2. to move down \n");
	printf("3. to move right \n");
	printf("4. to move left \n");
	printf("you direction = ");
	scanf("%d",&Direction_Shot);

		switch(Direction_Shot)
		{
		case 1: row--;
				while(Check_Hit && row > 0)
			    {

				  if(Game[row][col] == 'X')
				  {
					Game[row][col] = '-';
					Check_Hit=0;
				  }
				  else if(Game[row][col] == '@')Check_Hit=0;
						else 
							if(Game[row][col] == 'O')
							{
							 Option=999;
							 Check_Hit=0;
							 Game[row][col] = 'Hit';
							 if(Turn_Tank1==1)printf("Tank1 win \n");
							 else printf("Tank2 win \n");
							}
				  row--;
			    }//end while
			break;

		case 2:row++;
				while(Check_Hit && row < RowExseption-1)
			    {

				  if(Game[row][col] == 'X')
				  {
					Game[row][col] = '-';
					Check_Hit=0;
				  }
				  else if(Game[row][col] == '@')Check_Hit=0;
						else 
							if(Game[row][col] == 'O')
							{
							 Option=999;
							 Check_Hit=0;
							 Game[row][col] = 'Hit';
							 if(Turn_Tank1==1)printf("Tank1 win \n");
							 else printf("Tank2 win \n");
							}
				  row++;
			    }//end while
			break;

		case 3: col++;
				while(Check_Hit && col < ColExseption-1)
			    {

				  if(Game[row][col] == 'X')
				  {
					Game[row][col] = '-';
					Check_Hit=0;
				  }
				  else if(Game[row][col] == '@')Check_Hit=0;
						else 
							if(Game[row][col] == 'O')
							{
							 Option=999;
							 Check_Hit=0;
							 Game[row][col] = 'Hit';
							 if(Turn_Tank1==1)printf("Tank1 win \n");
							 else printf("Tank2 win \n");
							}
				  col++;
			    }//end while
			break;

		case 4: col--;
				while(Check_Hit && col > 0)
			    {

				  if(Game[row][col] == 'X')
				  {
					Game[row][col] = '-';
					Check_Hit=0;
				  }
				  else if(Game[row][col] == '@')Check_Hit=0;
						else 
							if(Game[row][col] == 'O')
							{
							 Option=999;
							 Check_Hit=0;
							 Game[row][col] = 'Hit';
							 if(Turn_Tank1==1)printf("Tank1 win \n");
								else printf("Tank2 win \n");
							}
				  col--;
			    }//end while
			break;

		default :
			break;
		}//end switch
}// Shot_Normal_Shot


void Move_Up(char Game[RowExseption][ColExseption] , int *row , int *col ,Number_Of_Steps)
{
	Number_Of_Steps--;
	int Check_Hit=1;
	Game[(*row)][(*col)]='-';
	(*row)=(*row)-1;
	while(Number_Of_Steps>0 && Check_Hit)
	{
		if(Game[(*row)][(*col)]!='@' && Game[(*row)][(*col)]!='X' && Game[(*row)][(*col)]!='O')
		{
			Number_Of_Steps--;
			(*row)=(*row)-1;
		}
		else
		{
			Check_Hit=0;
			(*row)=(*row)+1;
			Game[(*row)][(*col)]='O';
		}
	}//end while

	//(*row)=(*row)+1;
	Game[(*row)][(*col)]='O';

}//end Move_Up

void Move_Down(char Game[RowExseption][ColExseption] , int *row , int *col ,Number_Of_Steps)
{
	int Check_Hit=1;
	Number_Of_Steps--;
	Game[(*row)][(*col)]='-';
	(*row)=(*row)+1;
	while(Number_Of_Steps>0 && Check_Hit)
	{
		if(Game[(*row)][(*col)]!='@' && Game[(*row)][(*col)]!='X' && Game[(*row)][(*col)]!='O')
		{
			Number_Of_Steps--;
			(*row)=(*row)+1;
		}
		else
		{
			Check_Hit=0;
			(*row)=(*row)-1;
			Game[(*row)][(*col)]='O';
		}
	}//end while

	//(*row)=(*row)-1;
	Game[(*row)][(*col)]='O';

}//end Move_Down

void Move_Right(char Game[RowExseption][ColExseption] , int *row , int *col ,Number_Of_Steps)
{
	Number_Of_Steps--;
	int Check_Hit=1;
	Game[(*row)][(*col)]='-';
	(*col)=(*col)+1;
	while(Number_Of_Steps>0 && Check_Hit)
	{
		if(Game[(*row)][(*col)]!='@' && Game[(*row)][(*col)]!='X' && Game[(*row)][(*col)]!='O')
		{
			Number_Of_Steps--;
			(*col)=(*col)+1;
		}
		else
		{
			Check_Hit=0;
			(*col)=(*col)-1;
			Game[(*row)][(*col)]='O';
		}
	}//end while

	//(*col)=(*col)-1;
	Game[(*row)][(*col)]='O';

}//end Move_Right


void Move_Left(char Game[RowExseption][ColExseption] , int *row , int *col ,Number_Of_Steps)
{
	Number_Of_Steps--;
	int Check_Hit=1;
	Game[(*row)][(*col)]='-';
	(*col)=(*col)-1;
	while(Number_Of_Steps>0 && Check_Hit)
	{
		if(Game[(*row)][(*col)]!='@' && Game[(*row)][(*col)]!='X' && Game[(*row)][(*col)]!='O')
		{
			Number_Of_Steps--;
			(*col)=(*col)-1;
		}
		else
		{
			Check_Hit=0;
			(*col)=(*col)+1;
			Game[(*row)][(*col)]='O';
		}
	}//end while

	//(*col)=(*col)+1;
	Game[(*row)][(*col)]='O';

}//end Move_Left




void main()
{
	//create the array
	char Game[RowExseption][ColExseption];

	//fill the array
	Fill_The_Array(Game);

	//save the location of the tanks
	//tank1 (RowExseption/2 , 1)
	//tank2 (ColExseption/2 , Col)
	int Location[2][2]={ {RowExseption/2 , 1} , 
						 {ColExseption/2 , Col} };

	int Number_Of_Steps;//the steps

	//print the array
	Print(Game);

	//the option you can in the game
	printf("1. to move up \n");
	printf("2. to move down \n");
	printf("3. to move right \n");
	printf("4. to move left \n");
	printf("5. to shot a normal shot \n");
	printf("6. to shot a bomb \n");
	printf("7. to shot a change direcation shot (dont work)\n");
	printf("you are Tank1 your option is = ");
	scanf("%d",&Option);

	while(Option!=999)
	{
		switch(Option)
		{
		case 1: system("cls");
				printf("enter how many steps you want to move :  \n");
				scanf("%d",&Number_Of_Steps);
				if(Turn_Tank1==1) Move_Up(Game , &Location[0][0] , &Location[0][1],Number_Of_Steps);
			    else Move_Up(Game , &Location[1][0] , &Location[1][1],Number_Of_Steps);
				Print(Game);
			break;

		case 2: system("cls");
				printf("enter how many steps you want to down :  \n");
				scanf("%d",&Number_Of_Steps);
				if(Turn_Tank1==1) Move_Down(Game , &Location[0][0] , &Location[0][1],Number_Of_Steps);
			    else Move_Down(Game , &Location[1][0] , &Location[1][1],Number_Of_Steps);
				Print(Game);
			break;

		case 3: system("cls");
				printf("enter how many steps you want to right :  \n");
				scanf("%d",&Number_Of_Steps);
				if(Turn_Tank1==1) Move_Right(Game , &Location[0][0] , &Location[0][1],Number_Of_Steps);
			    else Move_Right(Game , &Location[1][0] , &Location[1][1],Number_Of_Steps);
				Print(Game);
			break;

		case 4: system("cls");
				printf("enter how many steps you want to left :  \n");
				scanf("%d",&Number_Of_Steps);
				if(Turn_Tank1==1) Move_Left(Game , &Location[0][0] , &Location[0][1],Number_Of_Steps);
			    else Move_Left(Game , &Location[1][0] , &Location[1][1],Number_Of_Steps);
				Print(Game);
			break;

		case 5: system("cls");
				if(Turn_Tank1==1)Shot_Normal_Shot(Game ,Location[0][0] ,Location[0][1]);
				else Shot_Normal_Shot(Game , Location[1][0] ,Location[1][1]);
				Print(Game);
			break;

		case 6: system("cls");
				int row,column;
				printf("enetr the row \n");
				scanf("%d",&row);
				printf("enter the column \n");
				scanf("%d",&column);
				Shot_Bomb(Game,row,column);
				Print(Game);
			break;

		case 7://i dont do the change shot becuse i dont have time 
			break;

		default :
			break;
		}//end switch

	if(Option!=999)
		{//if 
			printf("1. to move up \n");
			printf("2. to move down \n");
			printf("3. to move right \n");
			printf("4. to move left \n");
			printf("5. to shot a normal shot \n");
			printf("6. to shot a bomb \n");
			printf("7. to shot a change direcation shot \n");
			if(Turn_Tank1==1)
			{
				Turn_Tank2=1;
				Turn_Tank1=0;
				printf("you are Tank2 your option is = ");
			}
			else 
			{
				Turn_Tank2=0;
				Turn_Tank1=1;
				printf("you are Tank1 your option is = ");
			}
			scanf("%d",&Option);
			printf("cls");
		}//end if

	}//end while



	//stop the black screen
	int Stop_The_System;
	scanf("%d",&Stop_The_System);
}//end main