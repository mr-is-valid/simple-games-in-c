#include <stdio.h>
#include <time.h>
#include <stdlib.h>
#include <conio.h>

int Direction [][]= { {-1,0},{0,1},{1,0},{0,-1}};

void main()
{

}